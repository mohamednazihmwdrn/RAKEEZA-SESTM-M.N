import React, { useState, useMemo } from 'react';
import {
  ShoppingCart,
  Receipt,
  Users,
  Wallet,
  CreditCard,
  Tag,
  Briefcase,
  Target,
  Layers,
  Landmark,
  Building2,
  BarChart3,
  TrendingUp,
  TrendingDown,
  Calendar,
  X,
  FileSpreadsheet,
  Printer,
  ArrowUpRight,
  ArrowDownRight,
  Lightbulb,
  Scale,
} from 'lucide-react';
import { AppData, User, SaleInvoice } from '../types';
import {
  calculateAllActualInventoryStocks,
  auditCompanyFinancialIntegrity,
} from '../utils/accounting';
import { exportIncomeStatementToExcel } from '../utils/excelExport';
import { getScopedAppDataForBranch } from '../utils/branchIsolation';

interface HomeViewProps {
  appData: AppData;
  onNavigate: (page: string) => void;
  currentUser?: User;
}

// Helper to compute P&L metrics for any arbitrary date range
export function computeDateRangePnL(appData: AppData, start: string, end: string) {
  const allSalesInvoices: SaleInvoice[] = appData?.salesInvoices || [];
  const allItems = appData?.items || [];
  const allCashTransactions = appData?.cashTransactions || [];

  const filteredInvoices = allSalesInvoices.filter((inv) => {
    if (!inv || inv.status === 'cancelled') return false;
    const invDate = inv.date || '';
    return invDate >= start && invDate <= end;
  });

  let grossSales = 0;
  let salesReturns = 0;
  let totalCogs = 0;
  const itemProfits: Record<string, { name: string; qty: number; revenue: number; profit: number }> = {};

  filteredInvoices.forEach((inv) => {
    const isReturn = inv.type === 'return_nagdi' || inv.type === 'return_ajel' || (inv as any).isReturn;
    const invTotal = Number(inv.total || 0);

    if (isReturn) {
      salesReturns += Math.abs(invTotal);
    } else {
      grossSales += invTotal;
    }

    const lines = inv.items || [];
    lines.forEach((line) => {
      const qty = Number(line.qty ?? (line as any).quantity ?? 0);
      const price = Number(line.price || 0);
      const lineRevenue = qty * price;

      const matchedItem = allItems.find(
        (it) => it.id === line.itemId || it.name.trim().toLowerCase() === (line.name || '').trim().toLowerCase()
      );
      const costPrice = Number((line as any).costPrice ?? matchedItem?.costPrice ?? matchedItem?.price ?? 0);
      const lineCost = qty * costPrice;
      const lineProfit = lineRevenue - lineCost;

      if (isReturn) {
        totalCogs -= lineCost;
      } else {
        totalCogs += lineCost;
      }

      const itemName = line.name || matchedItem?.name || 'صنف';
      if (!itemProfits[itemName]) {
        itemProfits[itemName] = { name: itemName, qty: 0, revenue: 0, profit: 0 };
      }
      if (isReturn) {
        itemProfits[itemName].qty -= qty;
        itemProfits[itemName].revenue -= lineRevenue;
        itemProfits[itemName].profit -= lineProfit;
      } else {
        itemProfits[itemName].qty += qty;
        itemProfits[itemName].revenue += lineRevenue;
        itemProfits[itemName].profit += lineProfit;
      }
    });
  });

  const netSales = Math.max(0, grossSales - salesReturns);
  const safeCogs = Math.max(0, totalCogs);
  const grossProfit = netSales - safeCogs;
  const grossProfitMargin = netSales > 0 ? (grossProfit / netSales) * 100 : 0;

  let periodExpenses = 0;
  allCashTransactions.forEach((tx) => {
    if (!tx || (tx as any).status === 'cancelled') return;
    const txDate = tx.date || '';
    if (txDate >= start && txDate <= end) {
      if (tx.type === 'pay' || tx.type === 'withdraw') {
        if (!tx.supplierName && !tx.invoiceId) {
          periodExpenses += Number(tx.amount || 0);
        }
      }
    }
  });

  const netOperatingProfit = grossProfit - periodExpenses;
  const netProfitMargin = netSales > 0 ? (netOperatingProfit / netSales) * 100 : 0;

  const topItems = Object.values(itemProfits)
    .filter((i) => i.revenue > 0)
    .sort((a, b) => b.profit - a.profit)
    .slice(0, 5);

  return {
    invoicesCount: filteredInvoices.length,
    grossSales,
    salesReturns,
    netSales,
    cogs: safeCogs,
    grossProfit,
    grossProfitMargin,
    periodExpenses,
    netOperatingProfit,
    netProfitMargin,
    topItems,
  };
}

export const HomeView: React.FC<HomeViewProps> = ({ appData, onNavigate }) => {
  const activeBranchId = appData.activeBranchId || appData.branches?.[0]?.id || 'br-main';
  const currentBranch = (appData.branches || []).find((b) => b.id === activeBranchId) || appData.branches?.[0];
  const scopedData = useMemo(() => getScopedAppDataForBranch(appData, activeBranchId), [appData, activeBranchId]);

  // 1. Precise Financial and Operational Audit for this active branch
  const financialAudit = auditCompanyFinancialIntegrity(scopedData);
  const actualStockMap = calculateAllActualInventoryStocks(scopedData);

  const totalSales = Number(financialAudit.netSales || 0);
  const totalPurchases = Number(financialAudit.netPurchases || 0);
  const stockValue = Number(financialAudit.inventoryValuation || 0);
  const currencySymbol = appData.settings?.currencySymbol || 'ج.م';

  const salesCount = (scopedData?.salesInvoices || []).length;
  const purchasesCount = (scopedData?.purchaseInvoices || []).length;
  const customersCount = (appData?.customers || []).length;
  const suppliersCount = (appData?.suppliers || []).length;

  // Real liquid breakdown for this branch
  const drawerCash = Number(scopedData?.cashBox?.drawer || 0);
  const vodafoneCash = Number(scopedData?.cashBox?.vodafone || 0);
  const instapayCash = Number(scopedData?.cashBox?.instapay || 0);
  const bankCash = Number(scopedData?.cashBox?.bank || 0);
  const totalLiquid = drawerCash + vodafoneCash + instapayCash + bankCash;

  const chequesUnderCollection = (appData?.cheques || []).filter(
    (c) => c.status === 'under_collection' || c.status === 'received'
  ).length;

  // --------------------------------------------------------------------------
  // 📊 أداة تحليل ومقارنة الأرباح بين فترتين زمنيتين (Decision Tool)
  // --------------------------------------------------------------------------
  const [isPnlModalOpen, setIsPnlModalOpen] = useState(false);
  const [pnlTab, setPnlTab] = useState<'single' | 'compare'>('single');

  // Dates for Period 1
  const todayStr = new Date().toISOString().split('T')[0];
  const firstDayOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1)
    .toISOString()
    .split('T')[0];

  const [startDate, setStartDate] = useState(firstDayOfMonth);
  const [endDate, setEndDate] = useState(todayStr);
  const [activePeriodPreset, setActivePeriodPreset] = useState<'today' | '7days' | 'month' | 'last_month' | 'quarter' | 'year' | 'custom'>('month');

  // Dates for Period 2 (Comparison Mode)
  const lastMonthStart = new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1).toISOString().split('T')[0];
  const lastMonthEnd = new Date(new Date().getFullYear(), new Date().getMonth(), 0).toISOString().split('T')[0];
  const [compStartDate, setCompStartDate] = useState(lastMonthStart);
  const [compEndDate, setCompEndDate] = useState(lastMonthEnd);
  const [compPreset, setCompPreset] = useState<'month_vs_last' | '7days_vs_prior' | 'quarter_vs_prior' | 'year_vs_prior' | 'custom'>('month_vs_last');

  // Quick period presets handler for single period
  const setPeriodPreset = (preset: 'today' | '7days' | 'month' | 'last_month' | 'quarter' | 'year') => {
    setActivePeriodPreset(preset);
    const now = new Date();
    const today = now.toISOString().split('T')[0];

    if (preset === 'today') {
      setStartDate(today);
      setEndDate(today);
    } else if (preset === '7days') {
      const past7 = new Date(now.getTime() - 6 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      setStartDate(past7);
      setEndDate(today);
    } else if (preset === 'month') {
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
      setStartDate(monthStart);
      setEndDate(today);
    } else if (preset === 'last_month') {
      const lastMonthS = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().split('T')[0];
      const lastMonthE = new Date(now.getFullYear(), now.getMonth(), 0).toISOString().split('T')[0];
      setStartDate(lastMonthS);
      setEndDate(lastMonthE);
    } else if (preset === 'quarter') {
      const currentQuarter = Math.floor(now.getMonth() / 3);
      const quarterStart = new Date(now.getFullYear(), currentQuarter * 3, 1).toISOString().split('T')[0];
      setStartDate(quarterStart);
      setEndDate(today);
    } else if (preset === 'year') {
      const yearStart = new Date(now.getFullYear(), 0, 1).toISOString().split('T')[0];
      setStartDate(yearStart);
      setEndDate(today);
    }
  };

  // Quick presets handler for Comparison Mode
  const setComparisonPreset = (type: 'month_vs_last' | '7days_vs_prior' | 'quarter_vs_prior' | 'year_vs_prior') => {
    setCompPreset(type);
    const now = new Date();
    const today = now.toISOString().split('T')[0];

    if (type === 'month_vs_last') {
      // Period 1: Current month
      setStartDate(new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0]);
      setEndDate(today);
      // Period 2: Previous month
      setCompStartDate(new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().split('T')[0]);
      setCompEndDate(new Date(now.getFullYear(), now.getMonth(), 0).toISOString().split('T')[0]);
    } else if (type === '7days_vs_prior') {
      // Period 1: Last 7 days
      setStartDate(new Date(now.getTime() - 6 * 86400000).toISOString().split('T')[0]);
      setEndDate(today);
      // Period 2: Previous 7 days
      setCompStartDate(new Date(now.getTime() - 13 * 86400000).toISOString().split('T')[0]);
      setCompEndDate(new Date(now.getTime() - 7 * 86400000).toISOString().split('T')[0]);
    } else if (type === 'quarter_vs_prior') {
      const currentQ = Math.floor(now.getMonth() / 3);
      setStartDate(new Date(now.getFullYear(), currentQ * 3, 1).toISOString().split('T')[0]);
      setEndDate(today);
      const priorQStartMonth = (currentQ - 1) * 3;
      setCompStartDate(new Date(now.getFullYear(), priorQStartMonth, 1).toISOString().split('T')[0]);
      setCompEndDate(new Date(now.getFullYear(), currentQ * 3, 0).toISOString().split('T')[0]);
    } else if (type === 'year_vs_prior') {
      setStartDate(new Date(now.getFullYear(), 0, 1).toISOString().split('T')[0]);
      setEndDate(today);
      setCompStartDate(new Date(now.getFullYear() - 1, 0, 1).toISOString().split('T')[0]);
      setCompEndDate(new Date(now.getFullYear() - 1, 11, 31).toISOString().split('T')[0]);
    }
  };

  // Computations for Period 1
  const periodAnalysis = useMemo(() => {
    const res = computeDateRangePnL(scopedData, startDate, endDate);

    // Smart Decision Making KPI (مؤشر القرار التحليلي السريع)
    let decisionBadge = {
      title: 'أداء متوازن ومستقر',
      color: 'text-amber-800 bg-amber-50 border-amber-300',
      recommendation: 'المبيعات مستقرة ولكن يفضل ضبط المصروفات لزيادة هامش الربح الصافي.',
    };

    if (res.netOperatingProfit > 0 && res.netProfitMargin >= 22) {
      decisionBadge = {
        title: 'أداء ربحي استثنائي وممتاز 🟢',
        color: 'text-emerald-800 bg-emerald-50 border-emerald-300',
        recommendation: 'مؤشر قرار إيجابي: هامش الربح ممتاز، نوصي بالتوسع في الأصناف الرابحة وضخ سيولة في المخزون.',
      };
    } else if (res.netOperatingProfit > 0 && res.netProfitMargin >= 10) {
      decisionBadge = {
        title: 'أداء صحي وجيد 🟡',
        color: 'text-blue-800 bg-blue-50 border-blue-300',
        recommendation: 'مؤشر قرار آمن: المنظومة تحقق أرباحاً جيدة، ركز على تقليل مردودات المبيعات وتحصيل الآجل.',
      };
    } else if (res.netOperatingProfit > 0 && res.netProfitMargin < 10) {
      decisionBadge = {
        title: 'هامش ربح حرج ومنخفض 🟠',
        color: 'text-orange-800 bg-orange-50 border-orange-300',
        recommendation: 'مؤشر قرار تحذيري: هامش الربح ضئيل. ينبغي مراجعة أسعار البيع والتفاوض مع الموردين على خصومات إضافية.',
      };
    } else if (res.netOperatingProfit <= 0) {
      decisionBadge = {
        title: 'عجز أو خسارة تشغيلية للفترة 🔴',
        color: 'text-rose-800 bg-rose-50 border-rose-300',
        recommendation: 'مؤشر قرار عاجل: المصروفات وتكلفة البضاعة تتجاوز صافي الإيرادات. راجع تسعير الأصناف وأوقف الهدر فوراً.',
      };
    }

    return { ...res, decisionBadge };
  }, [scopedData, startDate, endDate]);

  // Computations for Period 2 (Comparison)
  const compPeriodAnalysis = useMemo(() => {
    return computeDateRangePnL(scopedData, compStartDate, compEndDate);
  }, [scopedData, compStartDate, compEndDate]);

  // Growth / Decline calculations between Period 1 and Period 2
  const comparisonMetrics = useMemo(() => {
    const p1 = periodAnalysis;
    const p2 = compPeriodAnalysis;

    const diffSales = p1.netSales - p2.netSales;
    const salesGrowthRate = p2.netSales > 0 ? (diffSales / p2.netSales) * 100 : p1.netSales > 0 ? 100 : 0;

    const diffProfit = p1.netOperatingProfit - p2.netOperatingProfit;
    const profitGrowthRate =
      Math.abs(p2.netOperatingProfit) > 0
        ? (diffProfit / Math.abs(p2.netOperatingProfit)) * 100
        : p1.netOperatingProfit > 0
        ? 100
        : 0;

    const diffGross = p1.grossProfit - p2.grossProfit;
    const diffExpenses = p1.periodExpenses - p2.periodExpenses;

    let compareDecision = {
      title: 'أداء مستقر ومتقارب',
      color: 'text-slate-800 bg-slate-50 border-slate-300',
      text: 'نتائج الفترتين متقاربة. حافظ على كفاءة دورة التحصيل والمخزون.',
    };

    if (profitGrowthRate >= 15) {
      compareDecision = {
        title: `نمو ربحي ملحوظ (+${profitGrowthRate.toFixed(1)}%) 🚀`,
        color: 'text-emerald-800 bg-emerald-50 border-emerald-300',
        text: `قفزة ربحية ممتازة مقارنة بالفترة السابقة (+${diffProfit.toLocaleString(undefined, { maximumFractionDigits: 0 })} ${currencySymbol}). استمر على نفس سياسة التسعير وزيادة حجم المبيعات.`,
      };
    } else if (profitGrowthRate > 0) {
      compareDecision = {
        title: `نمو إيجابي طفيف (+${profitGrowthRate.toFixed(1)}%) 📈`,
        color: 'text-blue-800 bg-blue-50 border-blue-300',
        text: `الأرباح في اتجاه تصاعدي مقارنة بالفترة السابقة. ركز على تقليص المصروفات التشغيلية لتعظيم هامش الربح.`,
      };
    } else if (profitGrowthRate < -10) {
      compareDecision = {
        title: `تراجع حرج في الأرباح (${profitGrowthRate.toFixed(1)}%) ⚠️`,
        color: 'text-rose-800 bg-rose-50 border-rose-300',
        text: `تراجعت الأرباح بمقدار ${Math.abs(diffProfit).toLocaleString(undefined, { maximumFractionDigits: 0 })} ${currencySymbol} عن الفترة المقارنة. اتخذ قراراً فورياً بمراجعة أسعار البيع والتأكد من عدم زيادة المصروفات.`,
      };
    } else if (profitGrowthRate < 0) {
      compareDecision = {
        title: `تراجع طفيف في الأرباح (${profitGrowthRate.toFixed(1)}%) 📉`,
        color: 'text-amber-800 bg-amber-50 border-amber-300',
        text: `انخفاض طفيف في صافي الربح مقارنة بالفترة السابقة. تحقق من نسبة الخصومات الممنوحة أو ارتفاع تكلفة الشراء.`,
      };
    }

    return {
      diffSales,
      salesGrowthRate,
      diffProfit,
      profitGrowthRate,
      diffGross,
      diffExpenses,
      compareDecision,
    };
  }, [periodAnalysis, compPeriodAnalysis, currencySymbol]);

  const handleExportPnlExcel = () => {
    exportIncomeStatementToExcel({
      companyName: appData?.settings?.companyName || 'منظومة ركيزة RAKEEZA ERP',
      allSales: periodAnalysis.grossSales,
      allSalesReturns: periodAnalysis.salesReturns,
      netSalesRevenue: periodAnalysis.netSales,
      totalCOGS: periodAnalysis.cogs,
      grossProfit: periodAnalysis.grossProfit,
      operatingExpenses: periodAnalysis.periodExpenses,
      netIncome: periodAnalysis.netOperatingProfit,
    });
  };

  const handlePrintPnl = () => {
    window.print();
  };

  return (
    <div className="w-full max-w-7xl mx-auto flex flex-col gap-3 pb-8 text-slate-800" dir="rtl">
      {/* الهيدر العلوي: ترويسة مدمجة وواضحة للفرع المحدد */}
      <div className="bg-white text-slate-900 border border-slate-200 px-3.5 sm:px-4 py-2.5 rounded-xl flex flex-wrap items-center justify-between gap-2 text-xs sm:text-sm font-semibold">
        <div className="flex flex-wrap items-center gap-2 min-w-0">
          <span className="text-slate-900 font-semibold truncate">
            {appData?.settings?.companyName || 'المحاسب المحترف'}
          </span>
          {currentBranch && (
            <span className="inline-flex items-center gap-1.5 text-slate-600 text-xs font-medium">
              <span className="text-slate-300">·</span>
              <Building2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>فرع: {currentBranch.name}</span>
              <span className="text-slate-400 text-[11px]">
                ({currentBranch.isMain ? 'الرئيسي' : 'مستقل'})
              </span>
            </span>
          )}
        </div>
        <div className="hidden sm:flex items-center">
          <span className="text-xs font-medium text-slate-500">
            لوحة التحكم الرئيسية · حسابات وأرقام الفرع المحدد
          </span>
        </div>
      </div>

      {/* شبكة البطاقات الرئيسية: الـ 12 قسماً الفريدة */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
        {/* 1. المشتريات والتوريد */}
        <button
          type="button"
          onClick={() => onNavigate('purchases')}
          className="bg-white border border-slate-200 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-2 cursor-pointer relative transition-colors select-none group text-center"
          title="المشتريات والتوريد"
        >
          <span className="absolute top-2.5 left-2.5 text-[11px] font-semibold font-mono tabular-nums text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
            {purchasesCount}
          </span>
          <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 transition-colors">
            <ShoppingCart className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            المشتريات والتوريد
          </div>
        </button>

        {/* 2. المبيعات والفواتير */}
        <button
          type="button"
          onClick={() => onNavigate('sales')}
          className="bg-white border border-slate-200 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-2 cursor-pointer relative transition-colors select-none group text-center"
          title="المبيعات والفواتير"
        >
          <span className="absolute top-2.5 left-2.5 text-[11px] font-semibold font-mono tabular-nums text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
            {salesCount}
          </span>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 transition-colors">
            <Receipt className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            المبيعات والفواتير
          </div>
        </button>

        {/* 3. العملاء والموردين */}
        <button
          type="button"
          onClick={() => onNavigate('customers')}
          className="bg-white border border-slate-200 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-2 cursor-pointer relative transition-colors select-none group text-center"
          title="العملاء والموردين"
        >
          <span className="absolute top-2.5 left-2.5 text-[11px] font-semibold font-mono tabular-nums text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
            {customersCount + suppliersCount}
          </span>
          <div className="w-10 h-10 rounded-xl bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-600 transition-colors">
            <Users className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            العملاء والموردين
          </div>
        </button>

        {/* 4. الخزينة والسيولة */}
        <button
          type="button"
          onClick={() => onNavigate('treasury')}
          className="bg-white border border-slate-200 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-2 cursor-pointer relative transition-colors select-none group text-center"
          title="الخزينة والسيولة"
        >
          <span className="absolute top-2.5 left-2.5 text-[11px] font-semibold font-mono tabular-nums text-emerald-700 bg-emerald-50 border border-emerald-200 px-1.5 py-0.5 rounded max-w-[96px] truncate">
            {totalLiquid > 0 ? `${Math.round(totalLiquid).toLocaleString()} ${currencySymbol}` : '0'}
          </span>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 transition-colors">
            <Wallet className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            الخزينة والسيولة
          </div>
        </button>

        {/* 5. شيكات وأوراق قبض */}
        <button
          type="button"
          onClick={() => onNavigate('cheques')}
          className="bg-white border border-slate-200 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-1.5 cursor-pointer relative transition-colors select-none group text-center"
          title="شيكات وأوراق قبض"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 transition-colors">
            <CreditCard className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            شيكات وأوراق قبض
          </div>
          <div className="text-[11px] text-emerald-700 font-medium tabular-nums">
            {chequesUnderCollection > 0 ? `${chequesUnderCollection} تحت التحصيل` : 'تحت التحصيل'}
          </div>
        </button>

        {/* 6. إدارة الأسعار */}
        <button
          type="button"
          onClick={() => onNavigate('price_management')}
          className="bg-white border border-amber-300 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-1.5 cursor-pointer relative transition-colors select-none group text-center"
          title="إدارة الأسعار"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 transition-colors">
            <Tag className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            إدارة الأسعار
          </div>
          <div className="text-[11px] text-amber-700 font-medium">
            التسعير المركزي
          </div>
        </button>

        {/* 7. الموارد والرواتب */}
        <button
          type="button"
          onClick={() => onNavigate('hr_payroll')}
          className="bg-white border border-slate-200 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-1.5 cursor-pointer relative transition-colors select-none group text-center"
          title="الموارد والرواتب"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 transition-colors">
            <Briefcase className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            الموارد والرواتب
          </div>
          <div className="text-[11px] text-slate-500 font-medium">
            شؤون العاملين
          </div>
        </button>

        {/* 8. المندوبين والعمولات */}
        <button
          type="button"
          onClick={() => onNavigate('sales_reps')}
          className="bg-white border border-slate-200 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-1.5 cursor-pointer relative transition-colors select-none group text-center"
          title="المندوبين والعمولات"
        >
          <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600 transition-colors">
            <Target className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            المندوبين والعمولات
          </div>
          <div className="text-[11px] text-slate-500 font-medium">
            المبيعات الخارجية
          </div>
        </button>

        {/* 9. التصنيع و BOM */}
        <button
          type="button"
          onClick={() => onNavigate('manufacturing')}
          className="bg-white border border-slate-200 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-1.5 cursor-pointer relative transition-colors select-none group text-center"
          title="التصنيع و BOM"
        >
          <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-600 transition-colors">
            <Layers className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            التصنيع و BOM
          </div>
          <div className="text-[11px] text-slate-500 font-medium">
            أوامر الإنتاج
          </div>
        </button>

        {/* 10. الأصول والإهلاك */}
        <button
          type="button"
          onClick={() => onNavigate('fixed_assets')}
          className="bg-white border border-slate-200 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-1.5 cursor-pointer relative transition-colors select-none group text-center"
          title="الأصول والإهلاك"
        >
          <div className="w-10 h-10 rounded-xl bg-sky-50 border border-sky-100 flex items-center justify-center text-sky-600 transition-colors">
            <Landmark className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            الأصول والإهلاك
          </div>
          <div className="text-[11px] text-slate-500 font-medium">
            إدارة الأصول
          </div>
        </button>

        {/* 11. المطابقة البنكية */}
        <button
          type="button"
          onClick={() => onNavigate('bank_reconciliation')}
          className="bg-white border border-slate-200 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-1.5 cursor-pointer relative transition-colors select-none group text-center"
          title="المطابقة البنكية"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-700 transition-colors">
            <Building2 className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            المطابقة البنكية
          </div>
          <div className="text-[11px] text-emerald-700 font-medium">
            الحسابات البنكية
          </div>
        </button>

        {/* 12. أسعار الشركات والتصنيفات */}
        <button
          type="button"
          onClick={() => onNavigate('company_prices')}
          className="bg-white border border-slate-200 hover:border-blue-500 hover:bg-slate-50/80 rounded-xl p-3 sm:p-3.5 min-h-[104px] flex flex-col items-center justify-center gap-1.5 cursor-pointer relative transition-colors select-none group text-center"
          title="أسعار الشركات والتصنيفات"
        >
          <div className="w-10 h-10 rounded-xl bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-600 transition-colors">
            <Building2 className="w-5 h-5" />
          </div>
          <div className="text-xs sm:text-[13px] font-semibold text-slate-900 leading-snug">
            أسعار الشركات والتصنيفات
          </div>
          <div className="text-[11px] text-purple-700 font-medium">
            دليل الشركات والمخزون
          </div>
        </button>
      </div>

      {/* ملخص المؤشرات المالية والتشغيلية مع أداة تحليل الأرباح ومقارنة الفترات */}
      <div className="bg-white border border-slate-200 rounded-xl p-3.5 sm:p-4 flex flex-col gap-3">
        <div className="border-b border-slate-200 pb-2.5 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2">
          <div className="text-xs sm:text-sm font-semibold text-slate-900 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-blue-600 shrink-0" />
            <span>ملخص المؤشرات المالية والتشغيلية</span>
          </div>

          {/* زر أداة تحليل ومقارنة الأرباح */}
          <button
            type="button"
            onClick={() => setIsPnlModalOpen(true)}
            className="min-h-[40px] text-xs font-semibold px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            title="تحليل ومقارنة الأرباح بين فترتين زمنيتين لتعزيز اتخاذ القرار"
          >
            <Scale className="w-4 h-4 text-blue-600 shrink-0" />
            <span>أداة تحليل ومقارنة الأرباح</span>
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-2.5">
          {/* إجمالي المشتريات */}
          <button
            type="button"
            onClick={() => onNavigate('purchases')}
            className="bg-slate-50 border border-slate-200 hover:border-rose-300 rounded-lg p-2.5 flex flex-col items-center justify-center gap-1 text-center cursor-pointer transition-colors"
            title="فتح فواتير المشتريات"
          >
            <span className="text-xs text-slate-500 font-medium">
              إجمالي المشتريات
            </span>
            <span className="text-xs sm:text-sm font-semibold text-rose-700 font-mono tabular-nums">
              {totalPurchases.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currencySymbol}
            </span>
          </button>

          {/* إجمالي المبيعات */}
          <button
            type="button"
            onClick={() => onNavigate('sales')}
            className="bg-slate-50 border border-slate-200 hover:border-emerald-300 rounded-lg p-2.5 flex flex-col items-center justify-center gap-1 text-center cursor-pointer transition-colors"
            title="فتح فواتير المبيعات"
          >
            <span className="text-xs text-slate-500 font-medium">
              إجمالي المبيعات
            </span>
            <span className="text-xs sm:text-sm font-semibold text-emerald-700 font-mono tabular-nums">
              {totalSales.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currencySymbol}
            </span>
          </button>

          {/* عدد الموردين */}
          <button
            type="button"
            onClick={() => onNavigate('customers')}
            className="bg-slate-50 border border-slate-200 hover:border-blue-300 rounded-lg p-2.5 flex flex-col items-center justify-center gap-1 text-center cursor-pointer transition-colors"
            title="فتح دليل الموردين"
          >
            <span className="text-xs text-slate-500 font-medium">
              عدد الموردين
            </span>
            <span className="text-xs sm:text-sm font-semibold text-slate-900 font-mono tabular-nums">
              {suppliersCount}
            </span>
          </button>

          {/* عدد العملاء */}
          <button
            type="button"
            onClick={() => onNavigate('customers')}
            className="bg-slate-50 border border-slate-200 hover:border-purple-300 rounded-lg p-2.5 flex flex-col items-center justify-center gap-1 text-center cursor-pointer transition-colors"
            title="فتح دليل العملاء"
          >
            <span className="text-xs text-slate-500 font-medium">
              عدد العملاء
            </span>
            <span className="text-xs sm:text-sm font-semibold text-slate-900 font-mono tabular-nums">
              {customersCount}
            </span>
          </button>

          {/* قيمة المخزون الكلي */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5 flex flex-col items-center justify-center gap-1 text-center col-span-2 md:col-span-1">
            <span className="text-xs text-slate-500 font-medium">
              قيمة المخزون الكلي
            </span>
            <span className="text-xs sm:text-sm font-semibold text-amber-700 font-mono tabular-nums">
              {stockValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currencySymbol}
            </span>
          </div>
        </div>
      </div>

      {/* النافذة المنبثقة: أداة تحليل ومقارنة الأرباح */}
      {isPnlModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-[1px] z-50 flex items-center justify-center p-2.5 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-4 sm:p-6 shadow-xl border border-slate-200 my-auto animate-in fade-in zoom-in-95 duration-200" dir="rtl">
            {/* Header with Tab Switcher */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-200 mb-4 gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center font-semibold shrink-0">
                  {pnlTab === 'single' ? <BarChart3 className="w-5 h-5" /> : <Scale className="w-5 h-5" />}
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-semibold text-slate-900">
                    أداة تحليل الأرباح واتخاذ القرار السريعة
                  </h3>
                  <p className="text-xs text-slate-500">
                    تحليل دقيق للأرباح والخسائر ومقارنة الفترات لحساب معدلات النمو والتراجع
                  </p>
                </div>
              </div>

              {/* Mode Selector Tabs */}
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 self-stretch sm:self-auto justify-center">
                <button
                  type="button"
                  onClick={() => setPnlTab('single')}
                  className={`min-h-[38px] text-xs font-semibold px-3 py-1.5 rounded-lg transition cursor-pointer ${
                    pnlTab === 'single'
                      ? 'bg-white text-blue-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  فترة واحدة
                </button>
                <button
                  type="button"
                  onClick={() => setPnlTab('compare')}
                  className={`min-h-[38px] text-xs font-semibold px-3 py-1.5 rounded-lg transition cursor-pointer flex items-center gap-1 ${
                    pnlTab === 'compare'
                      ? 'bg-white text-blue-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Scale className="w-3.5 h-3.5" />
                  <span>مقارنة فترتين</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsPnlModalOpen(false)}
                  className="text-slate-500 hover:text-slate-900 min-w-[38px] min-h-[38px] flex items-center justify-center rounded-lg hover:bg-slate-200 transition mr-1 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* TAB 1: Single Period Analysis */}
            {pnlTab === 'single' && (
              <>
                <div className="mb-4">
                  <div className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-blue-600" />
                    <span>اختر الفترة الزمنية للتحليل:</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mb-2.5">
                    {[
                      { key: 'today', label: 'اليوم' },
                      { key: '7days', label: 'آخر 7 أيام' },
                      { key: 'month', label: 'هذا الشهر' },
                      { key: 'last_month', label: 'الشهر الماضي' },
                      { key: 'quarter', label: 'الربع الحالي' },
                      { key: 'year', label: 'العام الحالي' },
                    ].map((item) => (
                      <button
                        key={item.key}
                        type="button"
                        onClick={() => setPeriodPreset(item.key as any)}
                        className={`min-h-[36px] text-xs px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                          activePeriodPreset === item.key
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>

                  {/* Custom Date Inputs */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">
                        من تاريخ:
                      </label>
                      <input
                        type="date"
                        value={startDate}
                        onChange={(e) => {
                          setStartDate(e.target.value);
                          setActivePeriodPreset('custom');
                        }}
                        className="w-full min-h-[42px] bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-base sm:text-xs text-slate-800 font-mono focus:outline-none focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-600 mb-1">
                        إلى تاريخ:
                      </label>
                      <input
                        type="date"
                        value={endDate}
                        onChange={(e) => {
                          setEndDate(e.target.value);
                          setActivePeriodPreset('custom');
                        }}
                        className="w-full min-h-[42px] bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-base sm:text-xs text-slate-800 font-mono focus:outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Smart Decision Card */}
                <div className={`p-3 rounded-xl border mb-4 flex items-start gap-2.5 ${periodAnalysis.decisionBadge.color}`}>
                  <Lightbulb className="w-5 h-5 shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs font-semibold">
                      {periodAnalysis.decisionBadge.title}
                    </div>
                    <div className="text-xs leading-relaxed mt-0.5">
                      {periodAnalysis.decisionBadge.recommendation}
                    </div>
                  </div>
                </div>

                {/* Financial Summary Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-4">
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-center">
                    <span className="text-xs text-slate-500 font-medium block mb-1">
                      صافي مبيعات الفترة
                    </span>
                    <span className="text-sm sm:text-base font-semibold text-slate-900 font-mono tabular-nums block">
                      {periodAnalysis.netSales.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currencySymbol}
                    </span>
                    <span className="text-[11px] text-slate-400 tabular-nums">
                      {periodAnalysis.invoicesCount} فاتورة بيع
                    </span>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-center">
                    <span className="text-xs text-slate-500 font-medium block mb-1">
                      تكلفة البضاعة المباعة (COGS)
                    </span>
                    <span className="text-sm sm:text-base font-semibold text-rose-600 font-mono tabular-nums block">
                      {periodAnalysis.cogs.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currencySymbol}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      تكلفة الأصناف المباعة
                    </span>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-center col-span-2 sm:col-span-1">
                    <span className="text-xs text-slate-500 font-medium block mb-1">
                      مجمل الربح (Gross Profit)
                    </span>
                    <span className={`text-sm sm:text-base font-semibold font-mono tabular-nums block ${periodAnalysis.grossProfit >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                      {periodAnalysis.grossProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currencySymbol}
                    </span>
                    <span className="text-[11px] font-medium text-emerald-700 tabular-nums">
                      هامش: {periodAnalysis.grossProfitMargin.toFixed(1)}%
                    </span>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-center">
                    <span className="text-xs text-slate-500 font-medium block mb-1">
                      المصروفات التشغيلية
                    </span>
                    <span className="text-sm sm:text-base font-semibold text-amber-600 font-mono tabular-nums block">
                      {periodAnalysis.periodExpenses.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currencySymbol}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      مصروفات النثرية والخزينة
                    </span>
                  </div>

                  <div className="bg-emerald-50/50 border border-emerald-300 rounded-xl p-2.5 text-center col-span-2">
                    <span className="text-xs text-emerald-800 font-semibold block mb-0.5">
                      صافي الربح التشغيلي النهائي للفترة
                    </span>
                    <span className={`text-base sm:text-lg font-bold font-mono tabular-nums block ${periodAnalysis.netOperatingProfit >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                      {periodAnalysis.netOperatingProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currencySymbol}
                    </span>
                    <span className="text-xs font-medium text-slate-600 tabular-nums">
                      صافي هامش الربح: {periodAnalysis.netProfitMargin.toFixed(1)}%
                    </span>
                  </div>
                </div>

                {/* Top Profitable Items Table */}
                {periodAnalysis.topItems.length > 0 && (
                  <div className="border border-slate-200 rounded-xl overflow-hidden mb-4">
                    <div className="bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-700 border-b border-slate-200">
                      الأصناف الأكثر مساهمة في أرباح الفترة:
                    </div>
                    <div className="divide-y divide-slate-100 text-xs">
                      {periodAnalysis.topItems.map((item, idx) => (
                        <div key={idx} className="px-3 py-2 flex items-center justify-between hover:bg-slate-50 gap-2">
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="w-5 h-5 rounded bg-slate-200 text-slate-700 text-[11px] font-semibold flex items-center justify-center shrink-0 tabular-nums">
                              {idx + 1}
                            </span>
                            <span className="font-semibold text-slate-800 truncate">{item.name}</span>
                            <span className="text-[11px] text-slate-400 shrink-0 tabular-nums">({item.qty} وحدة)</span>
                          </div>
                          <div className="text-left font-mono tabular-nums shrink-0">
                            <span className="text-emerald-700 font-semibold">
                              +{item.profit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currencySymbol}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* TAB 2: Period 1 vs Period 2 Comparison Mode */}
            {pnlTab === 'compare' && (
              <div className="space-y-4">
                <div>
                  <div className="text-xs font-semibold text-slate-700 mb-2 flex items-center gap-1.5">
                    <Scale className="w-3.5 h-3.5 text-blue-600" />
                    <span>اختر نمط المقارنة المسبق:</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mb-2.5">
                    {[
                      { key: 'month_vs_last', label: 'الشهر الحالي مقابل السابق' },
                      { key: '7days_vs_prior', label: 'آخر 7 أيام مقابل السابقة' },
                      { key: 'quarter_vs_prior', label: 'الربع الحالي مقابل السابق' },
                      { key: 'year_vs_prior', label: 'العام الحالي مقابل السابق' },
                    ].map((btn) => (
                      <button
                        key={btn.key}
                        type="button"
                        onClick={() => setComparisonPreset(btn.key as any)}
                        className={`min-h-[36px] text-xs px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                          compPreset === btn.key
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {btn.label}
                      </button>
                    ))}
                  </div>

                  {/* Dual Period Date Selectors */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <div className="sm:border-l border-slate-200 sm:pl-3">
                      <div className="text-xs font-semibold text-blue-700 mb-1.5">
                        الفترة الحالية (الفترة 1):
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[11px] font-medium text-slate-500 mb-0.5">من:</label>
                          <input
                            type="date"
                            value={startDate}
                            onChange={(e) => {
                              setStartDate(e.target.value);
                              setCompPreset('custom');
                            }}
                            className="w-full min-h-[40px] bg-white border border-slate-300 rounded-lg px-2 py-1 text-base sm:text-xs font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-slate-500 mb-0.5">إلى:</label>
                          <input
                            type="date"
                            value={endDate}
                            onChange={(e) => {
                              setEndDate(e.target.value);
                              setCompPreset('custom');
                            }}
                            className="w-full min-h-[40px] bg-white border border-slate-300 rounded-lg px-2 py-1 text-base sm:text-xs font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <div className="text-xs font-semibold text-slate-600 mb-1.5">
                        الفترة المقارنة (الفترة 2):
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[11px] font-medium text-slate-500 mb-0.5">من:</label>
                          <input
                            type="date"
                            value={compStartDate}
                            onChange={(e) => {
                              setCompStartDate(e.target.value);
                              setCompPreset('custom');
                            }}
                            className="w-full min-h-[40px] bg-white border border-slate-300 rounded-lg px-2 py-1 text-base sm:text-xs font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-slate-500 mb-0.5">إلى:</label>
                          <input
                            type="date"
                            value={compEndDate}
                            onChange={(e) => {
                              setCompEndDate(e.target.value);
                              setCompPreset('custom');
                            }}
                            className="w-full min-h-[40px] bg-white border border-slate-300 rounded-lg px-2 py-1 text-base sm:text-xs font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Executive Comparison Decision Banner */}
                <div className={`p-3 rounded-xl border flex items-start gap-2.5 ${comparisonMetrics.compareDecision.color}`}>
                  <Lightbulb className="w-5 h-5 shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs font-semibold">
                      {comparisonMetrics.compareDecision.title}
                    </div>
                    <div className="text-xs leading-relaxed mt-0.5">
                      {comparisonMetrics.compareDecision.text}
                    </div>
                  </div>
                </div>

                {/* Key Growth Indicators */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center">
                    <span className="text-xs text-slate-500 font-medium block mb-1">
                      نسبة نمو الأرباح الصافية
                    </span>
                    <div className="flex items-center justify-center gap-1">
                      {comparisonMetrics.profitGrowthRate >= 0 ? (
                        <ArrowUpRight className="w-5 h-5 text-emerald-600" />
                      ) : (
                        <ArrowDownRight className="w-5 h-5 text-rose-600" />
                      )}
                      <span
                        className={`text-base sm:text-lg font-bold font-mono tabular-nums ${
                          comparisonMetrics.profitGrowthRate >= 0 ? 'text-emerald-700' : 'text-rose-600'
                        }`}
                      >
                        {comparisonMetrics.profitGrowthRate >= 0 ? '+' : ''}
                        {comparisonMetrics.profitGrowthRate.toFixed(1)}%
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-500 font-mono tabular-nums block mt-0.5">
                      الفارق: {comparisonMetrics.diffProfit >= 0 ? '+' : ''}
                      {comparisonMetrics.diffProfit.toLocaleString(undefined, { maximumFractionDigits: 0 })} {currencySymbol}
                    </span>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center">
                    <span className="text-xs text-slate-500 font-medium block mb-1">
                      نسبة نمو صافي المبيعات
                    </span>
                    <div className="flex items-center justify-center gap-1">
                      {comparisonMetrics.salesGrowthRate >= 0 ? (
                        <ArrowUpRight className="w-5 h-5 text-blue-600" />
                      ) : (
                        <ArrowDownRight className="w-5 h-5 text-rose-600" />
                      )}
                      <span
                        className={`text-base sm:text-lg font-bold font-mono tabular-nums ${
                          comparisonMetrics.salesGrowthRate >= 0 ? 'text-blue-700' : 'text-rose-600'
                        }`}
                      >
                        {comparisonMetrics.salesGrowthRate >= 0 ? '+' : ''}
                        {comparisonMetrics.salesGrowthRate.toFixed(1)}%
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-500 font-mono tabular-nums block mt-0.5">
                      الفارق: {comparisonMetrics.diffSales >= 0 ? '+' : ''}
                      {comparisonMetrics.diffSales.toLocaleString(undefined, { maximumFractionDigits: 0 })} {currencySymbol}
                    </span>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-center col-span-2 sm:col-span-1">
                    <span className="text-xs text-slate-500 font-medium block mb-1">
                      تغير المصروفات التشغيلية
                    </span>
                    <span
                      className={`text-base sm:text-lg font-bold font-mono tabular-nums block ${
                        comparisonMetrics.diffExpenses <= 0 ? 'text-emerald-700' : 'text-amber-700'
                      }`}
                    >
                      {comparisonMetrics.diffExpenses >= 0 ? '+' : ''}
                      {comparisonMetrics.diffExpenses.toLocaleString(undefined, { maximumFractionDigits: 0 })} {currencySymbol}
                    </span>
                    <span className="text-[11px] text-slate-400 block mt-0.5">
                      {comparisonMetrics.diffExpenses <= 0 ? 'انخفاض في المصاريف (إيجابي)' : 'زيادة في المصاريف'}
                    </span>
                  </div>
                </div>

                {/* Comparative Financial Table */}
                <div className="border border-slate-200 rounded-xl overflow-x-auto">
                  <table className="w-full text-xs text-right min-w-[460px]">
                    <thead>
                      <tr className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
                        <th className="p-2.5">البند المالي</th>
                        <th className="p-2.5 text-center text-blue-700">الفترة الحالية (1)</th>
                        <th className="p-2.5 text-center text-slate-600">الفترة المقارنة (2)</th>
                        <th className="p-2.5 text-center">التغير / النمو</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
                      <tr className="hover:bg-slate-50">
                        <td className="p-2.5 font-sans font-semibold text-slate-800">صافي المبيعات</td>
                        <td className="p-2.5 text-center font-semibold text-blue-700">
                          {periodAnalysis.netSales.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                        <td className="p-2.5 text-center text-slate-600">
                          {compPeriodAnalysis.netSales.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                        <td className={`p-2.5 text-center font-semibold ${comparisonMetrics.salesGrowthRate >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {comparisonMetrics.salesGrowthRate >= 0 ? '+' : ''}{comparisonMetrics.salesGrowthRate.toFixed(1)}%
                        </td>
                      </tr>

                      <tr className="hover:bg-slate-50">
                        <td className="p-2.5 font-sans font-semibold text-slate-800">تكلفة البضاعة (COGS)</td>
                        <td className="p-2.5 text-center text-rose-600 font-semibold">
                          {periodAnalysis.cogs.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                        <td className="p-2.5 text-center text-slate-600">
                          {compPeriodAnalysis.cogs.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                        <td className="p-2.5 text-center text-slate-500">
                          {periodAnalysis.cogs >= compPeriodAnalysis.cogs ? '+' : ''}
                          {(periodAnalysis.cogs - compPeriodAnalysis.cogs).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                      </tr>

                      <tr className="hover:bg-slate-50">
                        <td className="p-2.5 font-sans font-semibold text-slate-800">مجمل الربح (Gross Profit)</td>
                        <td className="p-2.5 text-center font-semibold text-emerald-600">
                          {periodAnalysis.grossProfit.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                          <span className="text-[11px] text-slate-400 block font-normal">({periodAnalysis.grossProfitMargin.toFixed(1)}%)</span>
                        </td>
                        <td className="p-2.5 text-center text-slate-600">
                          {compPeriodAnalysis.grossProfit.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                          <span className="text-[11px] text-slate-400 block font-normal">({compPeriodAnalysis.grossProfitMargin.toFixed(1)}%)</span>
                        </td>
                        <td className={`p-2.5 text-center font-semibold ${comparisonMetrics.diffGross >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {comparisonMetrics.diffGross >= 0 ? '+' : ''}{comparisonMetrics.diffGross.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                      </tr>

                      <tr className="hover:bg-slate-50">
                        <td className="p-2.5 font-sans font-semibold text-slate-800">المصروفات التشغيلية</td>
                        <td className="p-2.5 text-center text-amber-600 font-semibold">
                          {periodAnalysis.periodExpenses.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                        <td className="p-2.5 text-center text-slate-600">
                          {compPeriodAnalysis.periodExpenses.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                        <td className="p-2.5 text-center text-slate-500">
                          {comparisonMetrics.diffExpenses >= 0 ? '+' : ''}{comparisonMetrics.diffExpenses.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </td>
                      </tr>

                      <tr className="bg-emerald-50/60 font-semibold">
                        <td className="p-2.5 font-sans text-emerald-950">صافي الربح التشغيلي النهائي</td>
                        <td className="p-2.5 text-center text-emerald-800 text-sm">
                          {periodAnalysis.netOperatingProfit.toLocaleString(undefined, { maximumFractionDigits: 0 })} {currencySymbol}
                          <span className="text-[11px] text-emerald-700 block font-normal">({periodAnalysis.netProfitMargin.toFixed(1)}%)</span>
                        </td>
                        <td className="p-2.5 text-center text-slate-700 text-sm">
                          {compPeriodAnalysis.netOperatingProfit.toLocaleString(undefined, { maximumFractionDigits: 0 })} {currencySymbol}
                          <span className="text-[11px] text-slate-500 block font-normal">({compPeriodAnalysis.netProfitMargin.toFixed(1)}%)</span>
                        </td>
                        <td className={`p-2.5 text-center text-sm ${comparisonMetrics.profitGrowthRate >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                          {comparisonMetrics.profitGrowthRate >= 0 ? '▲ +' : '▼ '}
                          {comparisonMetrics.profitGrowthRate.toFixed(1)}%
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Footer Actions */}
            <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 mt-4">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleExportPnlExcel}
                  className="min-h-[42px] px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>تصدير Excel</span>
                </button>
                <button
                  type="button"
                  onClick={handlePrintPnl}
                  className="min-h-[42px] px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>طباعة</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => setIsPnlModalOpen(false)}
                className="min-h-[42px] px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold transition cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
